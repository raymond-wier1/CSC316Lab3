﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

using System;
using System.Collections.Generic;

namespace simple_first_3d_game
{
    public class Game1 : Game
    {
        private GraphicsDeviceManager _graphics;
        private SpriteBatch _spriteBatch;

        Model player;
        Model barrel;

        SpriteFont normalFont;
        SpriteFont largeFont;

        Vector3 playerPos;
        List<Vector3> barrelPos;
        Vector3 barrelInitPos;
        Vector3 cameraPos;

        KeyboardState kState;

        double score = 0;
        float timer = 0f;

        Boolean jump;
        Boolean gameover;

        const float TARGET_RADIUS = 3.75f;
        public Game1()
        {
            _graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
            IsMouseVisible = true;
        }

        protected override void Initialize()
        {
            // TODO: Add your initialization logic here
            playerPos = new Vector3(0.0f, 0.0f, 0);
            cameraPos = new Vector3(playerPos.X, 10, 20);

            barrelInitPos = new Vector3(20, 0, 0);
            barrelPos = new List<Vector3>();

            gameover = false;
            jump = false;

            base.Initialize();
        }

        protected override void LoadContent()
        {
            _spriteBatch = new SpriteBatch(GraphicsDevice);

            // TODO: use this.Content to load your game content here
            player = Content.Load<Model>("Animal_Rigged_Zebu_01");
            barrel = Content.Load<Model>("Barrel_Sealed_01");

            normalFont = Content.Load<SpriteFont>("normalFont");
            largeFont = Content.Load<SpriteFont>("largeFont");
        }

        protected override void Update(GameTime gameTime)
        {
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
                Exit();

            // TODO: Add your update logic here

            kState = Keyboard.GetState();
            if (gameover == false)
            {
                // timer
                timer = timer + (float)gameTime.ElapsedGameTime.TotalSeconds;

                //Barrels
                if (Math.Floor(gameTime.TotalGameTime.TotalMilliseconds) % 2000 == 0)
                {
                    barrelPos.Add(barrelInitPos);
                }
                // Move Barrels
                for (int b = 0; b < barrelPos.Count; b++)
                {
                    barrelPos[b] -= new Vector3(0.1f, 0, 0);
                }
                // remove barrels
                if (barrelPos.Exists(a => a.X < -10))
                {
                    barrelPos.RemoveAll(a => a.X < -10);
                    score++;
                }

                // Simulated Hit Box
                for (int b = 0; b < barrelPos.Count; b++)
                {
                    if (Math.Abs(playerPos.X - barrelPos[b].X) < TARGET_RADIUS && playerPos.Y < TARGET_RADIUS - 0.65)
                    {
                        gameover = true;
                        break;
                    }
                }

                // move character

                if (kState.IsKeyDown(Keys.Left))
                {
                    playerPos.X -= 0.25f;
                }
                if (kState.IsKeyDown(Keys.Right))
                {
                    playerPos.X += 0.25f;
                }
                if (kState.IsKeyDown(Keys.Space))
                {
                    if (playerPos.Y < 7.5f)
                        playerPos.Y += 0.25f;

                }
                if (kState.IsKeyUp(Keys.Space))
                {
                    if (playerPos.Y > 0f)
                        playerPos.Y -= 0.25f;

                }



                // move camera
                if (kState.IsKeyDown(Keys.A))
                {
                    if (cameraPos.X < 7.5f)
                        cameraPos.X += 0.25f;
                }
                if (kState.IsKeyDown(Keys.D))
                {
                    if (cameraPos.X > -7.5f)
                        cameraPos.X -= 0.25f;
                }
                if (kState.IsKeyDown(Keys.W))
                {
                    if (cameraPos.Y < 7.5f)
                        cameraPos.Y += 0.25f;
                }
                if (kState.IsKeyDown(Keys.S))
                {
                    if (cameraPos.Y > -7.5f)
                        cameraPos.Y -= 0.25f;
                }
            }

            base.Update(gameTime);
        }

        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);

            // TODO: Add your drawing code here
            _spriteBatch.Begin();
            if (gameover == false)
            {
                _spriteBatch.DrawString(normalFont, "time: " + Math.Floor(timer).ToString(), new Vector2(3, 3), Color.White);
                _spriteBatch.DrawString(normalFont, "score: " + Math.Floor(score).ToString(), new Vector2(3, 20), Color.White);
                _spriteBatch.DrawString(normalFont, "Raymond Wier", new Vector2(675, 450), Color.White);
            }
            else
            {
                _spriteBatch.DrawString(largeFont, "GAME OVER", new Vector2(350, 225), Color.White);
                _spriteBatch.DrawString(normalFont, "time: " + Math.Floor(timer).ToString(), new Vector2(350, 255), Color.White);
                _spriteBatch.DrawString(normalFont, "score: " + Math.Floor(score).ToString(), new Vector2(350, 265), Color.White);
                _spriteBatch.DrawString(normalFont, "Raymond Wier", new Vector2(675, 450), Color.White);
            }
            _spriteBatch.End();

            // Draw Models
            Matrix proj = Matrix.CreatePerspectiveFieldOfView(MathHelper.ToRadians(60), 1, 0.001f, 1000f);

            Matrix view = Matrix.CreateLookAt(cameraPos, new Vector3(0,0,0), new Vector3(0,1,1));

            Matrix world = Matrix.CreateScale(0.005f) * Matrix.CreateRotationY(MathHelper.ToRadians(90)) * Matrix.CreateTranslation(playerPos);

            if (gameover == false)
            {
                player.Draw(world, view, proj);

                foreach (Vector3 pos in barrelPos)
                {
                    world = Matrix.CreateScale(0.1f) * Matrix.CreateTranslation(pos);
                    barrel.Draw(world, view, proj);
                }
            }

            base.Draw(gameTime);
        }
    }
}
